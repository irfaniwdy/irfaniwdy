<?php
defined('BASEPATH') or exit('No direct script allowed');

/*----------------------------------------REQUIRE THIS PLUGIN----------------------------------------*/
require APPPATH . '/libraries/REST_Controller.php';
//use Restserver\Libraries\REST_Controller;

class datates extends REST_Controller
{
    /*----------------------------------------CONSTRUCTOR----------------------------------------*/
    function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    /*----------------------------------------GET KONTAK----------------------------------------*/
    function index_get()
    {
        $x = $this->get('id');

        if ($x == '') {
            $kontak = $this->db->get('datates')->result();
        } else {
            $this->db->where('id', $x);
            $kontak = $this->db->get('datates')->result();
        }

        $this->response($kontak, 200);
    }

    function index_post()
    {
        $data = array(
            'pekerja'  =>    $this->post('pekerja'),
            'xt'    =>    $this->post('xt'),
            'yt'    =>    $this->post('yt'),
            'lantai' =>    $this->post('lantai')
        );
        $insert = $this->db->insert('datates', $data);

        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_put()
    {
        $mac = $this->put('pekerja');
        $data = array(
            'xt'    =>    $this->put('xt'),
            'yt'    =>    $this->put('yt'),
        );

        $this->db->where('pekerja', $mac);
        
        $update = $this->db->update('datates', $data);

        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail'), 502);
        }
    }
    
    function index_delete()
    {
        $x = $this->delete('xt');

        $this->db->where('xt', $x);

        $delete = $this->db->delete('datates');

        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail'), 502);
        }
    }
}