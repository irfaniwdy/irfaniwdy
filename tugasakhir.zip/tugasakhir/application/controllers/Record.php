<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class record extends CI_Controller {

    function __construct()
    {
    parent::__construct();
    $this->load->model('mjoin', '', TRUE);
    $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        
       // query memanggil function duatable di model
     $data['gabung'] = $this->mjoin->duatable();
     $this->load->view('header/header'); 
     $this->load->view('record',$data);
     $this->load->view('header/footer');    
     
    } 
     
   }

/* End of file Controllername.php */