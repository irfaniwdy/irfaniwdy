<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class pekerja extends CI_Controller {

    public function index()
    {
        $this->db->where('status', 'real');
        $data = array(
            'data_korban' => $this->db->get('korban')
         );
        
        
        $this->load->view('header/header');
        $this->load->view('pekerja',$data);
        $this->load->view('header/footer');
        
    }
    

    

}