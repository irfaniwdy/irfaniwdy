<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class tbl_pekerja extends CI_Controller {

    function __construct(){
		parent::__construct();		
		$this->load->model('M_tabel');
        $this->load->helper('url');
    }
    
    function index()
    {
        $data['user'] = $this->M_tabel->tampil_data()->result();
        $this->load->view('header/header');
        $this->load->view('tabel',$data);
        $this->load->view('header/footer');
    }
    function tambah()
    {
        $this->load->view('header/header');
        $this->load->view('add_form');
        $this->load->view('header/footer');

    }
    function tambah_aksi(){
        
        $nama = $this->input->post('nama');
        $mac = $this->input->post('mac');
        $divisi = $this->input->post('divisi');
        $data = array(
            
            'nama' => $nama,
            'mac' => $mac,
            'divisi' => $divisi
        );
        $this->M_tabel->input_data($data,'tbl_pekerja');
		redirect('tbl_pekerja');
        }

    function hapus($id){
            $where = array('id' => $id);
            $this->M_tabel->hapus_data($where,'tbl_pekerja');
            redirect('tbl_pekerja');
        }
     
    function edit($id){
            $where = array('id' => $id);
            $data['user'] = $this->M_tabel->edit_data($where,'tbl_pekerja')->result();
            $this->load->view('header/header');
            $this->load->view('edit_form',$data);
            $this->load->view('header/footer');
        }
    function update(){
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $mac = $this->input->post('mac');
            $divisi = $this->input->post('divisi');
         
            $data = array(
                'nama' => $nama,
                'mac' => $mac,
                'divisi' => $divisi
            );
         
            $where = array(
                'id' => $id
            );
         
            $this->M_tabel->update_data($where,$data,'tbl_pekerja');
            redirect('tbl_pekerja');
        }

    }

  

