<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {

    function __construct(){
		parent::__construct();		
		$this->load->model('m_dash');
        $this->load->helper('url');
    }

    public function index()
    {
        $this->db->where('status', 'prediksi');
        $data = array(
            'dtkorban' => $this->db->get('korban') 
         );
        $data['user']= $this->m_dash->ambil()->num_rows();
        
        $this->load->view('header/header');
        $this->load->view('dashboard', $data);
        $this->load->view('header/footer');
        
    }
    

    

}
 
/* End of file Controllername.php */
