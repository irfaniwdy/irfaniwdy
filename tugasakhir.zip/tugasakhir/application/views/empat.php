<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Data Korban</a></li>
                    <!---  <li class="active">Data table</li>-->
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Korban Lantai 4</strong>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Divisi</th>
                                    <th>Posisi x</th>
                                    <th>Posisi y</th>
                                    <th>Lantai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $jumlah=0;
                                foreach ($data_korban->result_array() as $key) {
                                    ?>
                                <tr>
                                    <td><?= $key['nama'];?></td>
                                    <td><?= $key['divisi'];?></td>
                                    <td><?= $key['xt'];?></td>
                                    <td><?= $key['yt'];?></td>
                                    <td><?= $key['lantai'];?></td>
                                </tr>
                                <?php
                                $jumlah+=1;
                                        }
                                        ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
        <p>Jumlah korban: <b><?= $jumlah; ?></b></p>
    </div><!-- .animated -->
</div><!-- .content -->

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Mapping</strong>
                    </div>
                    <div class="card-body">
                        <center>
                        <canvas id="myCanvas" width="500" height="300" style="border:5px solid #000000;">
                        </canvas>
                        <script type="text/javascript">
                            var canvas = document.getElementById("myCanvas");
                            var ctx = canvas.getContext("2d");

                            // gambar titik pada koordinat (10,10) dengan ukuran 1x1 px
                            ctx.beginPath(); // mulai menggmabar
                            ctx.moveTo(350,0);
                            ctx.lineTo(350,200);
                            ctx.stroke();
                            ctx.beginPath(); // mulai menggmabar
                            ctx.moveTo(350,200);
                            ctx.lineTo(500,200);
                            ctx.stroke();
                            ctx.beginPath(); // mulai menggmabar garasi
                            ctx.moveTo(350,200);
                            ctx.lineTo(350,300);
                            ctx.stroke();
                            ctx.strokeRect(200,0,150,100);//kt1
                            ctx.strokeRect(200,200,150,100);//kt2
                            ctx.strokeRect(150,235,50,100);//km1
                            ctx.beginPath(); // mulai menggmabar tembok km1
                            ctx.moveTo(150,200);
                            ctx.lineTo(150,300);
                            ctx.stroke();
                            ctx.strokeRect(100,235,50,100);//mulai gambar gudang
                            ctx.strokeRect(50,235,50,100);//mulai gambar km2
                            ctx.beginPath(); // mulai menggmabar dapur
                            ctx.moveTo(100,0);
                            ctx.lineTo(100,200);
                            ctx.stroke();
                            ctx.strokeRect(0,0,100,150);//kamar belakang
                            ctx.beginPath();
                            ctx.arc(421.95, 197, 2, 0, 2*Math.PI);
                            ctx.fillStyle = 'red';
                            ctx.fill();
                            ctx.lineWidth = 5;
                            ctx.strokeStyle= '#FF5733';
                            ctx.stroke();
                            ctx.beginPath();
                            ctx.arc(500, 300, 2, 0, 2*Math.PI);
                            ctx.fillStyle = 'green';
                            ctx.fill();
                            ctx.lineWidth = 5;
                            ctx.strokeStyle= '#FF5733';
                            ctx.stroke();
                            ctx.beginPath();
                            ctx.arc(421.95, 136, 2, 0, 2*Math.PI);
                            ctx.fillStyle = 'green';
                            ctx.fill();
                            ctx.lineWidth = 5;
                            ctx.strokeStyle= '#FF5733';
                            ctx.stroke();
                        </script> 
                        </center>
                          <p style="text-align:center"> 
                          <canvas id="draw" width="10" height="10" style="border:1px solid #FFFFFF;">
                          </canvas>
                          <script type="text/javascript">
                            var canvas = document.getElementById("draw");
                            var ctx = canvas.getContext("2d");
                            ctx.beginPath();
                            ctx.arc(5, 5, 1, 0, 2*Math.PI);
                            ctx.fillStyle = 'green';
                            ctx.fill();
                            ctx.lineWidth = 5;
                            ctx.strokeStyle= '#FF5733';
                            ctx.stroke();
                            </script>
                          
                          <b> Titik Prediksi Korban</b></p>               
                    </div>
                   
                         
                </div>
            </div>
        </div>
    </div>
</div>




</div><!-- /#right-panel -->

<!-- Right Panel -->