<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Data Pekerja</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    
                    <!---  <li class="active">Data table</li>-->
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                   
                    </div>
                    <div class="card-body">
                    <a href="<?php echo site_url('add') ?>"><i class="fas fa-plus"></i> Add New</a>
                    <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Mac_address</Address></th>
                                    <th>Divisi</th>  
                                    <th>Action</th>                               
                            </thead>
                            <tbody>
									<?php foreach ($pekerja as $key): ?>
									<tr>
										<td width="150">
											<?php echo $key->nama ?>
										</td>
										<td>
											<?php echo $key->mac_add ?>
										</td>
										<td>
											<?php echo $key->divisi ?>
										</td>
										<td width="250">
											<a href="<?php echo site_url('edit/'.$key->id) ?>"
											 class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
											<a onclick="deleteConfirm('<?php echo site_url('delete'.$key->id) ?>')"
											 href="#!" class="btn btn-small text-danger"><i class="fas fa-trash"></i> Hapus</a>
										</td>
									</tr>
									<?php endforeach; ?>

								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>	
    </div>

                <script>
                function deleteConfirm(url){
                    $('#btn-delete').attr('href', url);
                    $('#deleteModal').modal();
                }
                </script>