<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Tambah Data</a></li>
                    <!---  <li class="active">Data table</li>-->
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Input Data</strong>
                    </div>
                    <div class="card-body card-block">
                    <form action="<?php echo base_url(). 'tbl_pekerja/tambah_aksi'; ?>" method="post" class="form-horizontal">
                    <div class="row form-group">
                    <div class="col col-md-3"><label for="nama" class=" form-control-label">Nama</label></div>
                    <div class="col-12 col-md-9"><input type="text"  name="nama" placeholder="Masukkan nama..." class="form-control"><span class="help-block"></span></div>
                    </div>

                    <div class="row form-group">
                    <div class="col col-md-3"><label for="mac" class=" form-control-label">Mac Address</label></div>
                    <div class="col-12 col-md-9"><input type="text"  name="mac" placeholder="Masukkan mac address..." class="form-control"><span class="help-block"></span></div>
                    </div>
                          
                    <div class="row form-group">
                    <div class="col col-md-3"><label for="divisi" class=" form-control-label">Divisi</label></div>
                    <div class="col-12 col-md-9"><input type="text"  name="divisi" placeholder="Masukkan divisi..." class="form-control"><span class="help-block"></span></div>
                    </div>
                                                         
                    <div class="card-footer">
                    <button type="submit"  class="btn btn-primary btn-sm">
                        <i class="fa fa-dot-circle-o"></i> Submit
                    </button>
                                                        
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>