 <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        

        <div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Description</strong>
                    </div>
                <div class="card-body">   
                    <div class="typo-headers">
                    <h2 class="pb-2 display-5">Building Evacuation Management System</h2>
                    <p>   </p>

                    <p>Building Evacuation Management System ini adalah sebuah website yang khusus digunakan untuk Security Building Admin dalam memprediksi posisi korban dan menghitung jumlah korban selama proses evakuasi di dalam gedung. Website ini akan melaporkan informasi mengenai korban di setiap lantai gedung. Pada proyek akhir ini area observasi yang digunakan adalah lantai 4 dan lantai 5.</p>

                    </div>
                 </div>
                 </div>
            </div>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="stat-widget-four">
                    <div class="stat-icon dib">
                        <i class="ti-user text-muted"></i>
                    </div>
                    <div class="stat-content">
                        <div class="text-left dib">
                               
                            <div class="stat-heading">Pekerja</div>
                            
                            <div class="stat-text">Total: <?= $user;?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="stat-widget-four">
                    <div class="stat-icon dib">
                        <i class="ti-user text-muted"></i>
                    </div>
                    <div class="stat-content">
                        <div class="text-left dib">
                            <div class="stat-heading">Korban terjebak</div>
                            <div class="stat-text">Total: <?= $dtkorban->num_rows();?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    </div>
    </div><!-- .animated -->
</div><!-- .content -->
           

            
            <!--/.col-->

            