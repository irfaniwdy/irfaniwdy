<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Data Pekerja</a></li>
                    <li><a href="#">Update Data</a></li>
                    <!---  <li class="active">Data table</li>-->
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Update Data</strong>
                    </div>
                    <div class="card-body card-block">
                    <?php foreach($user as $key){ ?>
                    <form action="<?php echo base_url(). 'tbl_pekerja/update'; ?>" method="post" class="form-horizontal">
                    <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                    <tr>
				    <td>Nama</td>
				    <td>
					<input type="hidden" name="id" value="<?php echo $key->id ?>">
					<input type="text" name="nama" value="<?php echo $key->nama ?>">
				    </td>
                    </tr>
                    <tr>
				    <td>Mac Address</td>
				    <td><input type="text" name="mac" value="<?php echo $key->mac ?>"></td>
                    </tr>
                    <tr>
				    <td>Divisi</td>
				    <td><input type="text" name="divisi" value="<?php echo $key->divisi ?>"></td>
                    </tr>
                    <tr>
				    <td></td>
				    <td><input type="submit" value="Simpan"></td>
                    </tr>
                    </table>
	                </form>	
                    <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                    
                                                        
                  