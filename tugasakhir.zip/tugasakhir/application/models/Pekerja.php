<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Pekerja extends CI_Model{	
    public function hitungpekerja(){
	
        
    $query = $this->db->get('dtpekerja');
    if($query->num_rows()>0)
    {
      return $query->num_rows();
    }
    else
    {
      return 0;
    }
 }
}




