<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_dash extends CI_Model {
  
    function ambil(){
       
        return $this->db->get('tbl_pekerja');
    }
}