<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mjoin extends CI_Model {
 
public function duatable() {
 $this->db->order_by('timestamp','DESC');
 $this->db->select('*');
 $this->db->from('Datates');
 $this->db->join('tbl_pekerja','tbl_pekerja.mac=Datates.pekerja');
 $query = $this->db->get();
 return $query->result();
}

}